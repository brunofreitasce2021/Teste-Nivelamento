﻿using System.Globalization;

namespace Questao1
{
    class ContaBancaria {
      
        public double Saldo { get; private set; }

        public ContaBancaria(int numero, string titular, double depositoInicial)
        {
           Saldo = depositoInicial;
        }

        public void Deposito(double quantia)
        {
            Saldo = Saldo + quantia;
			
        }

        public void Saque(double quantia)
        {
            Saldo = Saldo - quantia;
        }
    }
}
       
    

