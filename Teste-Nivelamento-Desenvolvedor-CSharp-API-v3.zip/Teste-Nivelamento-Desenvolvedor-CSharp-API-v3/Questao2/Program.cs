﻿using Newtonsoft.Json;
using System;
using System.Net.Http;

public class Program
{
    public static void Main()
    {
        string teamName = "Paris Saint-Germain";
        int year = 2013;
        int totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team "+ teamName +" scored "+ totalGoals.ToString() + " goals in "+ year);

        teamName = "Chelsea";
        year = 2014;
        totalGoals = getTotalScoredGoals(teamName, year);

        Console.WriteLine("Team " + teamName + " scored " + totalGoals.ToString() + " goals in " + year);

        // Output expected:
        // Team Paris Saint - Germain scored 109 goals in 2013
        // Team Chelsea scored 92 goals in 2014
    }

     public static int GetTotalScoredGoals(string teamName, int year)
    {
        int totalGoals = 0;
        int currentPage = 1;
        int totalPages = int.MaxValue;

        using (HttpClient client = new HttpClient())
        {
            while (currentPage <= totalPages)
            {
                string response = await client.GetStringAsync($"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={teamName}&page={currentPage}");
                JObject jsonResponse = JObject.Parse(response);

                totalPages = (int)jsonResponse["total_pages"];
                foreach (var match in jsonResponse["data"])
                {
                    if (match["team1"].ToString() == team)
                    {
                        totalGoals = totalGoals + int.Parse(match["team1goals"].ToString());
                    }
                    if (match["team2"].ToString() == team)
                    {
                        totalGoals = totalGoals + int.Parse(match["team2goals"].ToString());
                    }
                }
                currentPage++;
            }
        }

        return totalGoals;
    }

}